from setuptools import setup, find_packages

setup(
    name="color-contrast-linter",
    version="0.1.0",
    description="A CLI tool to lint color pairs for contrast compliance using cm-colors.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Lalitha Kanha", # Assuming user name from path, can be updated
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.8",
    install_requires=[
        "cm-colors>=0.5.0",
        "click",
        "rich",
        "pyyaml",
    ],
    entry_points={
        "console_scripts": [
            "cc-lint=color_contrast_linter.cli:main",
        ],
    },
)
